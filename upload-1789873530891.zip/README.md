# REGA DOWNLOADER

Downloader sederhana untuk URL publik Facebook, Instagram, YouTube, dan TikTok.

## Stack

- Node.js + Express
- yt-dlp sebagai media extractor
- FFmpeg untuk merge video/audio
- HTML/CSS/JS frontend
- Docker

## Menjalankan secara lokal

### 1. Install dependency

```bash
npm install
```

### 2. Install yt-dlp

Pastikan command berikut tersedia:

```bash
yt-dlp --version
ffmpeg -version
```

### 3. Start

```bash
npm start
```

Buka:

```text
http://localhost:3000
```

## Docker

```bash
docker compose up -d --build
```

## Catatan

Extractor bergantung pada perubahan situs/platform. Jika sebuah platform mengubah sistemnya, versi yt-dlp perlu diperbarui.

Project ini tidak mencoba bypass login, DRM, private content, paywall, atau access control.
Gunakan hanya untuk media yang memang boleh kamu unduh.
