import express from "express";
import cors from "cors";
import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;
const DOWNLOAD_DIR = path.join(__dirname, "..", "downloads");

fs.mkdirSync(DOWNLOAD_DIR, { recursive: true });

app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "..", "public")));

const SUPPORTED = {
  youtube: ["youtube.com", "youtu.be"],
  tiktok: ["tiktok.com"],
  instagram: ["instagram.com"],
  facebook: ["facebook.com", "fb.watch"]
};

function detectPlatform(rawUrl) {
  let u;
  try {
    u = new URL(rawUrl);
  } catch {
    return null;
  }

  const host = u.hostname.toLowerCase().replace(/^www\./, "");

  for (const [platform, domains] of Object.entries(SUPPORTED)) {
    if (domains.some(d => host === d || host.endsWith("." + d))) {
      return platform;
    }
  }
  return null;
}

function safeName(name) {
  return (name || "video")
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, "_")
    .slice(0, 120);
}

function runYtDlp(args) {
  return new Promise((resolve, reject) => {
    const child = spawn("yt-dlp", args, { windowsHide: true });
    let stdout = "";
    let stderr = "";

    child.stdout.on("data", d => stdout += d.toString());
    child.stderr.on("data", d => stderr += d.toString());

    child.on("error", err => {
      if (err.code === "ENOENT") {
        reject(new Error("yt-dlp tidak ditemukan. Install yt-dlp dan pastikan masuk PATH."));
      } else {
        reject(err);
      }
    });

    child.on("close", code => {
      if (code === 0) resolve(stdout);
      else reject(new Error(stderr || `yt-dlp keluar dengan kode ${code}`));
    });
  });
}

app.post("/api/resolve", async (req, res) => {
  try {
    const { url } = req.body;

    if (!url || typeof url !== "string") {
      return res.status(400).json({ success: false, error: "URL wajib diisi." });
    }

    const platform = detectPlatform(url);
    if (!platform) {
      return res.status(400).json({
        success: false,
        error: "Platform tidak didukung. Gunakan Facebook, Instagram, YouTube, atau TikTok."
      });
    }

    // --dump-single-json mengambil metadata tanpa mengunduh media.
    const output = await runYtDlp([
      "--dump-single-json",
      "--no-warnings",
      "--no-playlist",
      url
    ]);

    const info = JSON.parse(output);

    const formats = (info.formats || [])
      .filter(f => f.url && (f.ext === "mp4" || f.ext === "webm"))
      .map(f => ({
        formatId: f.format_id,
        ext: f.ext,
        quality: f.height ? `${f.height}p` : (f.format_note || "audio/video"),
        height: f.height || 0,
        fps: f.fps || null,
        filesize: f.filesize || f.filesize_approx || null,
        hasVideo: !!f.vcodec && f.vcodec !== "none",
        hasAudio: !!f.acodec && f.acodec !== "none"
      }))
      .sort((a, b) => b.height - a.height);

    res.json({
      success: true,
      platform,
      title: info.title || "Untitled",
      uploader: info.uploader || info.channel || null,
      thumbnail: info.thumbnail || null,
      duration: info.duration || null,
      formats
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get("/api/download", async (req, res) => {
  try {
    const { url, format = "best" } = req.query;

    if (!url) return res.status(400).send("URL wajib diisi.");

    const platform = detectPlatform(url);
    if (!platform) return res.status(400).send("Platform tidak didukung.");

    const id = crypto.randomBytes(8).toString("hex");
    const outputTemplate = path.join(DOWNLOAD_DIR, `${id}.%(ext)s`);

    // Hanya format yang dikontrol aplikasi.
    const allowed =
      format === "best"
        ? "bv*+ba/b"
        : /^[0-9]+$/.test(format)
          ? format
          : "bv*+ba/b";

    await runYtDlp([
      "--no-playlist",
      "--merge-output-format", "mp4",
      "-f", allowed,
      "-o", outputTemplate,
      url
    ]);

    const files = fs.readdirSync(DOWNLOAD_DIR)
      .filter(f => f.startsWith(id + "."));

    if (!files.length) throw new Error("File hasil download tidak ditemukan.");

    const file = path.join(DOWNLOAD_DIR, files[0]);
    const stat = fs.statSync(file);

    res.setHeader("Content-Type", "application/octet-stream");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${safeName(files[0])}"`
    );
    res.setHeader("Content-Length", stat.size);

    const stream = fs.createReadStream(file);
    stream.pipe(res);

    stream.on("close", () => {
      fs.unlink(file, () => {});
    });
  } catch (err) {
    res.status(500).send(`Download gagal: ${err.message}`);
  }
});

app.get("/api/health", (_, res) => {
  res.json({ success: true, service: "REGA DOWNLOADER" });
});

app.listen(PORT, () => {
  console.log(`REGA DOWNLOADER running at http://localhost:${PORT}`);
});